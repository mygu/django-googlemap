================
django-googlemap
================

django-googlemap is a simple Django app to show the google map from ip addresses.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "django-googlemap" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = (
        ...
        'googlemap',
    )


